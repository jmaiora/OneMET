// charts.jsx — SVG data-viz primitives for OneMET
// Exports: ActivityRings, GlucoseChart, MetBars, HeartChart, Sparkline,
//          TIRBar, TrendBars, CorrScatter

const CW = 338; // logical chart width (card inner width)

// smooth path through points [[x,y],...] using Catmull-Rom → bezier
function smoothPath(pts) {
  if (pts.length < 2) return '';
  let d = `M ${pts[0][0]},${pts[0][1]}`;
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i];
    const p1 = pts[i];
    const p2 = pts[i + 1];
    const p3 = pts[i + 2] || p2;
    const c1x = p1[0] + (p2[0] - p0[0]) / 6;
    const c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6;
    const c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ` C ${c1x},${c1y} ${c2x},${c2y} ${p2[0]},${p2[1]}`;
  }
  return d;
}

// ── Activity rings ────────────────────────────────────────────
function ActivityRings({ size = 132, stroke = 13, gap = 4 }) {
  const T = window.TOKENS;
  const rings = [
    { color: T.ringMove, frac: DATA.rings.move.value / DATA.rings.move.goal },
    { color: T.ringExer, frac: DATA.rings.exer.value / DATA.rings.exer.goal },
    { color: T.ringMet,  frac: DATA.rings.met.value  / DATA.rings.met.goal  },
  ];
  const c = size / 2;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      {rings.map((r, i) => {
        const radius = c - stroke / 2 - i * (stroke + gap);
        const circ = 2 * Math.PI * radius;
        const frac = Math.min(r.frac, 1);
        return (
          <g key={i} transform={`rotate(-90 ${c} ${c})`}>
            <circle cx={c} cy={c} r={radius} fill="none"
              stroke={r.color} strokeOpacity="0.18" strokeWidth={stroke} />
            <circle cx={c} cy={c} r={radius} fill="none"
              stroke={r.color} strokeWidth={stroke} strokeLinecap="round"
              strokeDasharray={`${circ * frac} ${circ}`} />
          </g>
        );
      })}
    </svg>
  );
}

// ── Glucose chart (hero) ──────────────────────────────────────
function GlucoseChart({ height = 168, mmol = false, accent, showRun = true,
                        from = 0, to = 288, markCurrent = true }) {
  const T = window.TOKENS;
  const data = DATA.glucose.slice(from, to);
  const w = CW, h = height;
  const padT = 10, padB = 22, padL = 0, padR = 30;
  const gMin = 40, gMax = 240;
  const n = data.length;
  const x = i => padL + (i / (n - 1)) * (w - padL - padR);
  const y = v => padT + (1 - (v - gMin) / (gMax - gMin)) * (h - padT - padB);
  const pts = data.map((v, i) => [x(i), y(v)]);
  const line = smoothPath(pts);
  const yLow = y(TARGET_LOW), yHigh = y(TARGET_HIGH);

  // run window in absolute idx 192..216 → relative
  const rs = Math.max(0, 192 - from), re = Math.min(n - 1, 216 - from);
  const curRel = DATA.currentIdx - from;
  const curPt = (curRel >= 0 && curRel < n) ? [x(curRel), y(data[curRel])] : null;
  const uid = React.useId().replace(/:/g, '');

  const hourLabels = [];
  for (let hLab = 0; hLab <= 24; hLab += 6) {
    const idx = (hLab * 12) - from;
    if (idx >= -2 && idx <= n + 2) {
      const lab = hLab === 0 ? '12A' : hLab === 12 ? '12P' : hLab < 12 ? `${hLab}A` : `${hLab - 12}P`;
      hourLabels.push({ x: x(Math.max(0, Math.min(n - 1, idx))), lab });
    }
  }

  return (
    <svg width="100%" viewBox={`0 0 ${w} ${h}`} style={{ display: 'block' }}>
      <defs>
        <linearGradient id={`gfill${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={accent} stopOpacity="0.18" />
          <stop offset="100%" stopColor={accent} stopOpacity="0" />
        </linearGradient>
      </defs>
      {/* target band */}
      <rect x={padL} y={yHigh} width={w - padL - padR} height={yLow - yHigh}
        fill={T.green} fillOpacity="0.09" />
      <line x1={padL} y1={yHigh} x2={w - padR} y2={yHigh} stroke={T.green} strokeOpacity="0.35" strokeWidth="1" strokeDasharray="2 3" />
      <line x1={padL} y1={yLow} x2={w - padR} y2={yLow} stroke={T.green} strokeOpacity="0.35" strokeWidth="1" strokeDasharray="2 3" />
      <text x={w - padR + 4} y={yHigh + 4} fontSize="10" fill={T.ink3} fontFamily="-apple-system">{mmol ? '10' : '180'}</text>
      <text x={w - padR + 4} y={yLow + 4} fontSize="10" fill={T.ink3} fontFamily="-apple-system">{mmol ? '3.9' : '70'}</text>

      {/* run highlight */}
      {showRun && re > rs && (
        <g>
          <rect x={x(rs)} y={padT} width={x(re) - x(rs)} height={h - padT - padB}
            fill={accent} fillOpacity="0.06" />
          <text x={(x(rs) + x(re)) / 2} y={padT + 11} fontSize="9.5" textAnchor="middle"
            fill={accent} fontFamily="-apple-system" fontWeight="600" letterSpacing="0.3">RUN</text>
        </g>
      )}

      {/* area + line */}
      <path d={`${line} L ${x(n - 1)},${h - padB} L ${x(0)},${h - padB} Z`} fill={`url(#gfill${uid})`} />
      <path d={line} fill="none" stroke={accent} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />

      {/* current marker */}
      {markCurrent && curPt && (
        <g>
          <circle cx={curPt[0]} cy={curPt[1]} r="6.5" fill="#fff" />
          <circle cx={curPt[0]} cy={curPt[1]} r="4.5" fill={accent} />
        </g>
      )}

      {/* hour labels */}
      {hourLabels.map((hl, i) => (
        <text key={i} x={hl.x} y={h - 5} fontSize="10" textAnchor="middle"
          fill={T.ink3} fontFamily="-apple-system">{hl.lab}</text>
      ))}
    </svg>
  );
}

// ── MET bars ──────────────────────────────────────────────────
function MetBars({ height = 96, accent }) {
  const T = window.TOKENS;
  const data = DATA.metByHour;
  const w = CW, h = height, padB = 16, padT = 6;
  const max = Math.max(...data, 1);
  const n = data.length;
  const slot = w / n;
  const bw = slot * 0.5;
  return (
    <svg width="100%" viewBox={`0 0 ${w} ${h}`} style={{ display: 'block' }}>
      {data.map((v, i) => {
        const bh = (v / max) * (h - padT - padB);
        const cx = i * slot + slot / 2;
        return (
          <rect key={i} x={cx - bw / 2} y={h - padB - bh} width={bw} height={Math.max(bh, v > 0 ? 2 : 0)}
            rx={bw / 2.5} fill={accent} fillOpacity={v >= max * 0.8 ? 1 : 0.42} />
        );
      })}
      {[0, 3, 6, 9, 11].map(i => {
        const hr = i * 2;
        const lab = hr === 0 ? '12A' : hr === 12 ? '12P' : hr < 12 ? `${hr}A` : `${hr - 12}P`;
        return <text key={i} x={i * slot + slot / 2} y={h - 3} fontSize="9.5" textAnchor="middle" fill={T.ink3} fontFamily="-apple-system">{lab}</text>;
      })}
    </svg>
  );
}

// ── Heart rate range chart ────────────────────────────────────
function HeartChart({ height = 92 }) {
  const T = window.TOKENS;
  const s = DATA.heart.series;
  const w = CW, h = height, padT = 8, padB = 6;
  const min = 45, max = 165;
  const n = s.length;
  const x = i => (i / (n - 1)) * w;
  const y = v => padT + (1 - (v - min) / (max - min)) * (h - padT - padB);
  const pts = s.map((v, i) => [x(i), y(v)]);
  return (
    <svg width="100%" viewBox={`0 0 ${w} ${h}`} style={{ display: 'block' }}>
      <path d={smoothPath(pts)} fill="none" stroke={T.red} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
      {pts.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r="2.4" fill={T.red} />)}
    </svg>
  );
}

// ── Sparkline ─────────────────────────────────────────────────
function Sparkline({ data, color, height = 36, width = 90 }) {
  const min = Math.min(...data), max = Math.max(...data);
  const x = i => (i / (data.length - 1)) * width;
  const y = v => 3 + (1 - (v - min) / (max - min || 1)) * (height - 6);
  const pts = data.map((v, i) => [x(i), y(v)]);
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} style={{ display: 'block' }}>
      <path d={smoothPath(pts)} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

// ── Time in range stacked bar (horizontal) ────────────────────
function TIRBar({ height = 14 }) {
  const T = window.TOKENS;
  const { low, inRange, high } = DATA.tir;
  const segs = [
    { v: low, c: T.red }, { v: inRange, c: T.green }, { v: high, c: T.amber },
  ];
  return (
    <div style={{ display: 'flex', width: '100%', height, borderRadius: height / 2, overflow: 'hidden', gap: 2 }}>
      {segs.map((s, i) => s.v > 0 && (
        <div key={i} style={{ width: `${s.v}%`, background: s.c, borderRadius: 3 }} />
      ))}
    </div>
  );
}

// ── 14-day TIR trend bars ─────────────────────────────────────
function TrendBars({ height = 150, accent }) {
  const T = window.TOKENS;
  const data = DATA.tirTrend;
  const w = CW, h = height, padB = 18, padT = 6;
  const n = data.length;
  const slot = w / n;
  const bw = slot * 0.56;
  const y = v => padT + (1 - v / 100) * (h - padT - padB);
  return (
    <svg width="100%" viewBox={`0 0 ${w} ${h}`} style={{ display: 'block' }}>
      <line x1={0} y1={y(70)} x2={w} y2={y(70)} stroke={T.green} strokeOpacity="0.4" strokeWidth="1" strokeDasharray="3 3" />
      <text x={2} y={y(70) - 4} fontSize="9.5" fill={T.green} fontFamily="-apple-system" fontWeight="600">70% goal</text>
      {data.map((v, i) => {
        const bh = (v / 100) * (h - padT - padB);
        const cx = i * slot + slot / 2;
        return <rect key={i} x={cx - bw / 2} y={h - padB - bh} width={bw} height={bh}
          rx={3} fill={v >= 70 ? T.green : accent} fillOpacity={v >= 70 ? 0.9 : 0.5} />;
      })}
      {[0, 6, 13].map(i => (
        <text key={i} x={i * slot + slot / 2} y={h - 4} fontSize="9.5" textAnchor="middle" fill={T.ink3} fontFamily="-apple-system">
          {i === 13 ? 'Today' : `${14 - i}d`}
        </text>
      ))}
    </svg>
  );
}

// ── Correlation scatter ───────────────────────────────────────
function CorrScatter({ height = 168, accent }) {
  const T = window.TOKENS;
  const data = DATA.corr;
  const w = CW, h = height, padL = 28, padB = 24, padT = 8, padR = 8;
  const xs = data.map(d => d[0]);
  const xMin = 80, xMax = 560;
  const yMin = 55, yMax = 95;
  const x = v => padL + ((v - xMin) / (xMax - xMin)) * (w - padL - padR);
  const y = v => padT + (1 - (v - yMin) / (yMax - yMin)) * (h - padT - padB);
  // simple trend line (least squares)
  const sorted = [...data].sort((a, b) => a[0] - b[0]);
  return (
    <svg width="100%" viewBox={`0 0 ${w} ${h}`} style={{ display: 'block' }}>
      {[60, 70, 80, 90].map(g => (
        <g key={g}>
          <line x1={padL} y1={y(g)} x2={w - padR} y2={y(g)} stroke={T.hair} strokeWidth="1" />
          <text x={2} y={y(g) + 3} fontSize="9.5" fill={T.ink3} fontFamily="-apple-system">{g}%</text>
        </g>
      ))}
      <path d={smoothPath(sorted.map(d => [x(d[0]), y(d[1])]))} fill="none"
        stroke={accent} strokeWidth="2" strokeOpacity="0.35" strokeDasharray="4 3" />
      {data.map((d, i) => (
        <circle key={i} cx={x(d[0])} cy={y(d[1])} r="4.5" fill={accent} fillOpacity="0.85" />
      ))}
      <text x={(padL + w - padR) / 2} y={h - 4} fontSize="9.5" textAnchor="middle" fill={T.ink3} fontFamily="-apple-system">MET·min per day →</text>
    </svg>
  );
}

// ── Single-workout glucose overlay (pre → during → post) ──────
function WorkoutChart({ workout, accent, height = 168 }) {
  const T = window.TOKENS;
  const data = workout.curve;
  const w = CW, h = height;
  const padT = 10, padB = 22, padL = 0, padR = 30;
  const gMin = 40, gMax = 240;
  const n = data.length;
  const x = i => padL + (i / (n - 1)) * (w - padL - padR);
  const y = v => padT + (1 - (v - gMin) / (gMax - gMin)) * (h - padT - padB);
  const pts = data.map((v, i) => [x(i), y(v)]);
  const line = smoothPath(pts);
  const yLow = y(TARGET_LOW), yHigh = y(TARGET_HIGH);
  const rs = x(workout.activityStart), re = x(workout.activityEnd);
  const uid = React.useId().replace(/:/g, '');

  return (
    <svg width="100%" viewBox={`0 0 ${w} ${h}`} style={{ display: 'block' }}>
      <defs>
        <linearGradient id={`wgfill${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={accent} stopOpacity="0.18" />
          <stop offset="100%" stopColor={accent} stopOpacity="0" />
        </linearGradient>
      </defs>
      <rect x={padL} y={yHigh} width={w - padL - padR} height={yLow - yHigh} fill={T.green} fillOpacity="0.09" />
      <line x1={padL} y1={yHigh} x2={w - padR} y2={yHigh} stroke={T.green} strokeOpacity="0.35" strokeWidth="1" strokeDasharray="2 3" />
      <line x1={padL} y1={yLow} x2={w - padR} y2={yLow} stroke={T.green} strokeOpacity="0.35" strokeWidth="1" strokeDasharray="2 3" />
      <text x={w - padR + 4} y={yHigh + 4} fontSize="10" fill={T.ink3} fontFamily="-apple-system">180</text>
      <text x={w - padR + 4} y={yLow + 4} fontSize="10" fill={T.ink3} fontFamily="-apple-system">70</text>

      <rect x={rs} y={padT} width={re - rs} height={h - padT - padB} fill={accent} fillOpacity="0.06" />
      <text x={(rs + re) / 2} y={padT + 11} fontSize="9.5" textAnchor="middle"
        fill={accent} fontFamily="-apple-system" fontWeight="600" letterSpacing="0.3">{workout.name.toUpperCase()}</text>

      <path d={`${line} L ${x(n - 1)},${h - padB} L ${x(0)},${h - padB} Z`} fill={`url(#wgfill${uid})`} />
      <path d={line} fill="none" stroke={accent} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />

      <text x={2} y={h - 5} fontSize="10" fill={T.ink3} fontFamily="-apple-system">Before</text>
      <text x={(rs + re) / 2} y={h - 5} fontSize="10" textAnchor="middle" fill={T.ink3} fontFamily="-apple-system">Activity</text>
      <text x={w - padR} y={h - 5} fontSize="10" textAnchor="end" fill={T.ink3} fontFamily="-apple-system">After</text>
    </svg>
  );
}

Object.assign(window, {
  ActivityRings, GlucoseChart, MetBars, HeartChart, Sparkline, TIRBar, TrendBars, CorrScatter, WorkoutChart,
});
