// cards.jsx — OneMET UI shell components
// Exports: Icon, Card, CardHead, Header, TabBar, StatBlock, Chip

function Icon({ name, color = 'currentColor', size = 17, stroke = 1.9 }) {
  const common = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none',
    stroke: color, strokeWidth: stroke, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const fillCommon = { width: size, height: size, viewBox: '0 0 24 24', fill: color };
  switch (name) {
    case 'drop': return <svg {...fillCommon}><path d="M12 2.5C12 2.5 5 10 5 15a7 7 0 0014 0c0-5-7-12.5-7-12.5z"/></svg>;
    case 'heart': return <svg {...fillCommon}><path d="M12 20.5l-1.4-1.27C5.4 14.5 2.5 11.9 2.5 8.6 2.5 6 4.5 4 7 4c1.7 0 3.3.9 4.1 2.3h1.8C13.7 4.9 15.3 4 17 4c2.5 0 4.5 2 4.5 4.6 0 3.3-2.9 5.9-8.1 10.63L12 20.5z"/></svg>;
    case 'flame': return <svg {...fillCommon}><path d="M12 2c.5 4-2.5 5-2.5 8 0 1 .5 2 1.5 2.4C10.3 11 11 9.5 11 9.5s.5 3.5 2.5 4.5c.3-.7.2-1.6.2-1.6s2.3 1.7 2.3 4.1A6 6 0 016 16.5C6 11 11 9 12 2z"/></svg>;
    case 'run': return <svg {...common}><circle cx="14.5" cy="4.5" r="1.8" fill={color} stroke="none"/><path d="M8 21l2.5-5 3-2-1.5-4-3 2-2 2.5M13.5 10l3 1.5 1 4M11 10l3.5-1.5"/></svg>;
    case 'shoe': return <svg {...common}><path d="M4 16v-5l3-1 2 3 3 .5 5 1.5c1 .3 2 1 2 2.5v.5H4v-2z"/></svg>;
    case 'fork': return <svg {...common}><path d="M7 3v7M5 3v4a2 2 0 002 2M9 3v4a2 2 0 01-2 2M7 11v10M17 3c-1.5 0-2.5 2-2.5 5s1 4 2.5 4 2.5-1 2.5-4-1-5-2.5-5zM17 12v9"/></svg>;
    case 'bolt': return <svg {...fillCommon}><path d="M13 2L4 14h6l-1 8 9-12h-6l1-8z"/></svg>;
    case 'activity': return <svg {...common}><path d="M3 12h4l2.5-7 4 16 2.5-9h5"/></svg>;
    case 'chevron': return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M9 5l7 7-7 7"/></svg>;
    case 'person': return <svg {...common}><circle cx="12" cy="8" r="3.5"/><path d="M5 20c0-3.5 3-6 7-6s7 2.5 7 6"/></svg>;
    case 'house': return <svg {...common}><path d="M4 11l8-7 8 7M6 9.5V20h12V9.5"/></svg>;
    case 'chart': return <svg {...common}><path d="M4 20V4M4 20h16M8 16v-4M12 16V8M16 16v-7"/></svg>;
    default: return null;
  }
}

function Card({ title, icon, iconColor, right, onClick, children, style = {}, pad = 16 }) {
  const T = window.TOKENS;
  return (
    <div onClick={onClick} style={{
      background: T.card, borderRadius: `var(--radius, 20px)`,
      padding: pad, boxShadow: '0 1px 2px rgba(0,0,0,0.04), 0 6px 16px rgba(0,0,0,0.035)',
      cursor: onClick ? 'pointer' : 'default', ...style,
    }}>
      {title && <CardHead title={title} icon={icon} iconColor={iconColor} right={right} clickable={!!onClick} />}
      {children}
    </div>
  );
}

function CardHead({ title, icon, iconColor, right, clickable }) {
  const T = window.TOKENS;
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        {icon && <Icon name={icon} color={iconColor} size={15} />}
        <span style={{ fontSize: 15, fontWeight: 600, color: iconColor || T.ink, letterSpacing: -0.2 }}>{title}</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
        {right && <span style={{ fontSize: 13, color: T.ink2, fontVariantNumeric: 'tabular-nums' }}>{right}</span>}
        {clickable && <Icon name="chevron" color={T.ink3} size={15} />}
      </div>
    </div>
  );
}

function Header({ title, date, accent }) {
  const T = window.TOKENS;
  return (
    <div style={{ padding: '4px 16px 8px', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
      <div>
        <div style={{ fontSize: 13, fontWeight: 600, color: T.ink2, letterSpacing: 0.2, textTransform: 'uppercase' }}>{date}</div>
        <div style={{ fontSize: 32, fontWeight: 700, color: T.ink, letterSpacing: 0.36, lineHeight: 1.1, marginTop: 2 }}>{title}</div>
      </div>
      <div style={{ width: 36, height: 36, borderRadius: 18, background: accent,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: '#fff', fontSize: 15, fontWeight: 600, boxShadow: '0 2px 6px rgba(0,0,0,0.12)' }}>AM</div>
    </div>
  );
}

function StatBlock({ label, value, unit, color }) {
  const T = window.TOKENS;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      <span style={{ fontSize: 12, fontWeight: 600, color: T.ink2, letterSpacing: 0.2, textTransform: 'uppercase' }}>{label}</span>
      <span style={{ display: 'flex', alignItems: 'baseline', gap: 3 }}>
        <span style={{ fontSize: 22, fontWeight: 700, color: color || T.ink, fontVariantNumeric: 'tabular-nums', letterSpacing: -0.3 }}>{value}</span>
        {unit && <span style={{ fontSize: 12, fontWeight: 600, color: T.ink2 }}>{unit}</span>}
      </span>
    </div>
  );
}

function Chip({ children, color }) {
  const T = window.TOKENS;
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '3px 9px', borderRadius: 100, background: (color || T.green) + '1f',
      fontSize: 12.5, fontWeight: 600, color: color || T.green, letterSpacing: -0.1 }}>{children}</span>
  );
}

function TabBar({ active, onChange, accent }) {
  const T = window.TOKENS;
  const tabs = [
    { id: 'summary', label: 'Summary', icon: 'house' },
    { id: 'activity', label: 'Activity', icon: 'flame' },
    { id: 'trends', label: 'Trends', icon: 'chart' },
    { id: 'profile', label: 'Profile', icon: 'person' },
  ];
  return (
    <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, zIndex: 40,
      paddingBottom: 22, paddingTop: 9,
      background: 'linear-gradient(to top, rgba(248,248,250,0.96) 60%, rgba(248,248,250,0))',
      backdropFilter: 'blur(18px) saturate(180%)', WebkitBackdropFilter: 'blur(18px) saturate(180%)',
      borderTop: `0.5px solid ${T.sep}`,
      display: 'flex', justifyContent: 'space-around', alignItems: 'flex-start' }}>
      {tabs.map(t => {
        const on = active === t.id;
        return (
          <div key={t.id} onClick={() => onChange(t.id)}
            style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, cursor: 'pointer', flex: 1, paddingTop: 2 }}>
            <Icon name={t.icon} color={on ? accent : T.ink3} size={24} stroke={on ? 2.2 : 1.9} />
            <span style={{ fontSize: 10.5, fontWeight: on ? 700 : 500, color: on ? accent : T.ink2 }}>{t.label}</span>
          </div>
        );
      })}
    </div>
  );
}

Object.assign(window, { Icon, Card, CardHead, Header, StatBlock, Chip, TabBar });
