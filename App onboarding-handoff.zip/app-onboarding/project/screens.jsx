// screens.jsx — OneMET screens (Summary, Activity, Trends, Profile, GlucoseDetail)

const SCROLL = {
  height: '100%', overflowY: 'auto', WebkitOverflowScrolling: 'touch',
  display: 'flex', flexDirection: 'column', gap: 14,
  padding: '56px 16px 120px',
};

function Arrow({ dir, color }) {
  // trend arrow: dir = 'up' | 'down' | 'flat'
  const rot = dir === 'up' ? -45 : dir === 'down' ? 45 : 0;
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" style={{ transform: `rotate(${rot}deg)` }}>
      <path d="M4 12h16M14 6l6 6-6 6" />
    </svg>
  );
}

// ── SUMMARY ───────────────────────────────────────────────────
function SummaryScreen({ accent, mmol, onOpenGlucose, onGoActivity, onGoTrends }) {
  const T = window.TOKENS;
  const st = glucoseStatus(DATA.current);
  const val = fmtGlucose(DATA.current, mmol);
  const unit = mmol ? 'mmol/L' : 'mg/dL';
  const r = DATA.rings;

  return (
    <div style={SCROLL}>
      <Header title="Summary" date="Friday, Jun 19" accent={accent} />

      {/* GLUCOSE HERO */}
      <Card icon="drop" iconColor={T.green} title="Glucose" right="Updated 2 min ago" onClick={onOpenGlucose}>
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 6 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
            <span style={{ fontSize: 52, fontWeight: 700, color: T.ink, letterSpacing: -1.5, lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>{val}</span>
            <span style={{ fontSize: 15, fontWeight: 600, color: T.ink2 }}>{unit}</span>
            <span style={{ marginLeft: 2 }}><Arrow dir="down" color={st.color} /></span>
          </div>
          <Chip color={st.color}><span style={{ width: 6, height: 6, borderRadius: 3, background: st.color, display: 'inline-block' }} />{st.label}</Chip>
        </div>
        <GlucoseChart accent={accent} mmol={mmol} height={158} />
        <div style={{ height: 1, background: T.hair, margin: '12px 0 12px' }} />
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
          <span style={{ fontSize: 12.5, fontWeight: 600, color: T.ink2, textTransform: 'uppercase', letterSpacing: 0.2 }}>Time in Range</span>
          <span style={{ fontSize: 13, fontWeight: 700, color: T.green }}>{DATA.tir.inRange}%</span>
        </div>
        <TIRBar />
        <div style={{ display: 'flex', gap: 14, marginTop: 9 }}>
          {[['Low', DATA.tir.low, T.red], ['In Range', DATA.tir.inRange, T.green], ['High', DATA.tir.high, T.amber]].map(([l, v, c]) => (
            <span key={l} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11.5, color: T.ink2, fontWeight: 500 }}>
              <span style={{ width: 7, height: 7, borderRadius: 4, background: c }} />{l} {v}%
            </span>
          ))}
        </div>
      </Card>

      {/* INSIGHT */}
      <div style={{ background: accent, borderRadius: 'var(--radius, 20px)', padding: 16, color: '#fff',
        boxShadow: '0 6px 18px ' + accent + '40' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 7 }}>
          <Icon name="bolt" color="#fff" size={15} />
          <span style={{ fontSize: 13, fontWeight: 700, letterSpacing: 0.2, textTransform: 'uppercase', opacity: 0.92 }}>Activity Insight</span>
        </div>
        <div style={{ fontSize: 17, fontWeight: 600, lineHeight: 1.35, letterSpacing: -0.2, textWrap: 'pretty' }}>
          Your 4:08 PM run lowered glucose by <span style={{ fontWeight: 800 }}>38 mg/dL</span> over 32 min — consider 15g carbs before similar sessions.
        </div>
      </div>

      {/* ACTIVITY RINGS */}
      <Card icon="flame" iconColor={T.ringMove} title="Activity" onClick={onGoActivity}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
          <ActivityRings size={118} stroke={12} />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 11, flex: 1 }}>
            <RingStat color={T.ringMove} label="Move" value={r.move.value} goal={r.move.goal} unit="kcal" />
            <RingStat color={T.ringExer} label="Exercise" value={r.exer.value} goal={r.exer.goal} unit="min" />
            <RingStat color={T.ringMet} label="MET" value={r.met.value} goal={r.met.goal} unit="MET·min" />
          </div>
        </div>
      </Card>

      {/* MET + HEART row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <Card icon="bolt" iconColor={T.ringMet} title="MET" pad={14}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 3 }}>
            <span style={{ fontSize: 30, fontWeight: 700, color: T.ink, letterSpacing: -0.8, fontVariantNumeric: 'tabular-nums' }}>486</span>
            <span style={{ fontSize: 12, fontWeight: 600, color: T.ink2 }}>MET·min</span>
          </div>
          <span style={{ fontSize: 11.5, color: T.ink2, fontWeight: 500 }}>Peak 9.1 on your run</span>
          <div style={{ marginTop: 8 }}><MetBars accent={T.ringMet} height={62} /></div>
        </Card>
        <Card icon="heart" iconColor={T.red} title="Heart" pad={14}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 3 }}>
            <span style={{ fontSize: 30, fontWeight: 700, color: T.ink, letterSpacing: -0.8, fontVariantNumeric: 'tabular-nums' }}>{DATA.heart.current}</span>
            <span style={{ fontSize: 12, fontWeight: 600, color: T.ink2 }}>BPM</span>
          </div>
          <span style={{ fontSize: 11.5, color: T.ink2, fontWeight: 500 }}>Range {DATA.heart.range[0]}–{DATA.heart.range[1]}</span>
          <div style={{ marginTop: 8 }}><HeartChart height={62} /></div>
        </Card>
      </div>

      {/* WORKOUTS */}
      <Card icon="run" iconColor={accent} title="Workouts" right="Today" onClick={onGoActivity}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {DATA.workouts.map((w, i) => (
            <WorkoutRow key={i} w={w} accent={accent} last={i === DATA.workouts.length - 1} />
          ))}
        </div>
      </Card>

      {/* NUTRITION */}
      <Card icon="fork" iconColor={T.amber} title="Carbs & Insulin" onClick={onGoTrends}>
        <div style={{ display: 'flex', gap: 24, marginBottom: 14 }}>
          <StatBlock label="Carbs" value={DATA.nutrition.carbs} unit="g" />
          <StatBlock label="Insulin" value={DATA.nutrition.insulinUnits} unit="U" color={accent} />
          <StatBlock label="Goal" value={DATA.nutrition.carbsGoal} unit="g" />
        </div>
        <div style={{ display: 'flex', gap: 4, height: 30, alignItems: 'flex-end' }}>
          {DATA.nutrition.meals.map((m, i) => (
            <div key={i} style={{ flex: m.carbs, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3 }}>
              <div style={{ width: '100%', height: 8, borderRadius: 4, background: T.amber, opacity: 0.55 + i * 0.12 }} />
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 4, marginTop: 5 }}>
          {DATA.nutrition.meals.map((m, i) => (
            <div key={i} style={{ flex: m.carbs, textAlign: 'center' }}>
              <div style={{ fontSize: 10, color: T.ink2, fontWeight: 600 }}>{m.name}</div>
              <div style={{ fontSize: 10, color: T.ink3, fontVariantNumeric: 'tabular-nums' }}>{m.carbs}g</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function RingStat({ color, label, value, goal, unit }) {
  const T = window.TOKENS;
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
        <span style={{ fontSize: 13, fontWeight: 600, color }}>{label}</span>
        <span style={{ fontSize: 18, fontWeight: 700, color: T.ink, fontVariantNumeric: 'tabular-nums', letterSpacing: -0.3 }}>{value}</span>
        <span style={{ fontSize: 11.5, color: T.ink2, fontWeight: 500 }}>/ {goal} {unit}</span>
      </div>
      <div style={{ height: 4, borderRadius: 2, background: color + '24', marginTop: 4, overflow: 'hidden' }}>
        <div style={{ width: Math.min(100, (value / goal) * 100) + '%', height: '100%', background: color, borderRadius: 2 }} />
      </div>
    </div>
  );
}

function WorkoutRow({ w, accent, last }) {
  const T = window.TOKENS;
  const dropColor = w.glucoseDelta < 0 ? T.green : T.amber;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0',
      borderBottom: last ? 'none' : `0.5px solid ${T.sep}` }}>
      <div style={{ width: 38, height: 38, borderRadius: 10, background: accent + '16',
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Icon name="run" color={accent} size={20} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 15, fontWeight: 600, color: T.ink }}>{w.name}</div>
        <div style={{ fontSize: 12.5, color: T.ink2 }}>{w.time} · {w.dist} · {w.dur}</div>
      </div>
      <div style={{ textAlign: 'right' }}>
        <Chip color={dropColor}>{w.glucoseDelta > 0 ? '+' : ''}{w.glucoseDelta} mg/dL</Chip>
        <div style={{ fontSize: 11, color: T.ink3, marginTop: 3, fontVariantNumeric: 'tabular-nums' }}>{w.avgMet} MET avg</div>
      </div>
    </div>
  );
}

// ── ACTIVITY ──────────────────────────────────────────────────
function ActivityScreen({ accent, onBack }) {
  const T = window.TOKENS;
  const r = DATA.rings;
  return (
    <div style={SCROLL}>
      <Header title="Activity" date="Friday, Jun 19" accent={accent} />
      <Card style={{ padding: 20 }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }}>
          <ActivityRings size={172} stroke={17} />
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <RingStat color={T.ringMove} label="Move" value={r.move.value} goal={r.move.goal} unit="kcal" />
          <RingStat color={T.ringExer} label="Exercise" value={r.exer.value} goal={r.exer.goal} unit="min" />
          <RingStat color={T.ringMet} label="MET" value={r.met.value} goal={r.met.goal} unit="MET·min" />
        </div>
      </Card>

      <Card icon="shoe" iconColor={T.teal} title="Steps & Distance">
        <div style={{ display: 'flex', gap: 24 }}>
          <StatBlock label="Steps" value={DATA.steps.toLocaleString()} color={T.teal} />
          <StatBlock label="Distance" value="6.6" unit="km" />
          <StatBlock label="Flights" value="11" />
        </div>
        <div style={{ height: 4, borderRadius: 2, background: T.teal + '24', marginTop: 12, overflow: 'hidden' }}>
          <div style={{ width: Math.min(100, (DATA.steps / DATA.stepsGoal) * 100) + '%', height: '100%', background: T.teal, borderRadius: 2 }} />
        </div>
        <div style={{ fontSize: 11.5, color: T.ink2, marginTop: 6 }}>{Math.round(DATA.steps / DATA.stepsGoal * 100)}% of {DATA.stepsGoal.toLocaleString()} goal</div>
      </Card>

      <Card icon="bolt" iconColor={T.ringMet} title="MET Minutes" right="Today">
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginBottom: 4 }}>
          <span style={{ fontSize: 34, fontWeight: 700, color: T.ink, letterSpacing: -1, fontVariantNumeric: 'tabular-nums' }}>486</span>
          <span style={{ fontSize: 13, fontWeight: 600, color: T.ink2 }}>MET·min</span>
        </div>
        <MetBars accent={T.ringMet} height={104} />
        <div style={{ fontSize: 12, color: T.ink2, marginTop: 6, textWrap: 'pretty' }}>Most activity 4–6 PM. 1 MET ≈ resting; running today peaked at 9.1 MET.</div>
      </Card>

      <Card icon="run" iconColor={accent} title="Workouts">
        {DATA.workouts.map((w, i) => (
          <WorkoutRow key={i} w={w} accent={accent} last={i === DATA.workouts.length - 1} />
        ))}
      </Card>
    </div>
  );
}

// ── TRENDS ────────────────────────────────────────────────────
function TrendsScreen({ accent, mmol }) {
  const T = window.TOKENS;
  return (
    <div style={SCROLL}>
      <Header title="Trends" date="Last 14 Days" accent={accent} />

      <Card icon="drop" iconColor={T.green} title="Time in Range" right="14-day">
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 4 }}>
          <span style={{ fontSize: 34, fontWeight: 700, color: T.green, letterSpacing: -1, fontVariantNumeric: 'tabular-nums' }}>82%</span>
          <span style={{ fontSize: 13, color: T.green, fontWeight: 600 }}>↑ 8% vs prior</span>
        </div>
        <TrendBars accent={accent} height={150} />
      </Card>

      <Card icon="bolt" iconColor={accent} title="Activity vs. Range">
        <div style={{ fontSize: 13.5, color: T.ink, lineHeight: 1.4, marginBottom: 10, textWrap: 'pretty' }}>
          Days with more MET minutes track with more time in range.
        </div>
        <CorrScatter accent={accent} height={168} />
        <div style={{ background: accent + '12', borderRadius: 12, padding: '10px 12px', marginTop: 12,
          display: 'flex', alignItems: 'center', gap: 9 }}>
          <Icon name="activity" color={accent} size={18} />
          <span style={{ fontSize: 13, color: T.ink, fontWeight: 500, lineHeight: 1.35, textWrap: 'pretty' }}>
            <span style={{ fontWeight: 700, color: accent }}>+0.7%</span> time in range for every extra 50 MET·min.
          </span>
        </div>
      </Card>

      <Card title="14-Day Summary">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '18px 14px' }}>
          <StatBlock label="Avg Glucose" value={fmtGlucose(DATA.avg, mmol)} unit={mmol ? 'mmol/L' : 'mg/dL'} />
          <StatBlock label="GMI / A1C" value="6.4" unit="%" color={T.green} />
          <StatBlock label="Avg MET·min" value="412" />
          <StatBlock label="Low Events" value="3" color={T.red} />
          <StatBlock label="Avg Steps" value="9,140" color={T.teal} />
          <StatBlock label="Workouts" value="9" color={accent} />
        </div>
      </Card>
    </div>
  );
}

// ── PROFILE ───────────────────────────────────────────────────
function ProfileScreen({ accent }) {
  const T = window.TOKENS;
  return (
    <div style={{ ...SCROLL, gap: 18 }}>
      <Header title="Profile" date="Account" accent={accent} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '4px 16px 6px' }}>
        <div style={{ width: 60, height: 60, borderRadius: 30, background: accent, color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, fontWeight: 600 }}>AM</div>
        <div>
          <div style={{ fontSize: 21, fontWeight: 700, color: T.ink }}>Alex Moreno</div>
          <div style={{ fontSize: 14, color: T.ink2 }}>Type 1 · since 2014</div>
        </div>
      </div>

      <IOSList header="Connected Devices">
        <IOSListRow title="CGM Sensor" detail="Connected" icon={T.green} />
        <IOSListRow title="Apple Watch" detail="Series 9" icon={T.red} />
        <IOSListRow title="Insulin Pen" detail="Synced 9:41" icon={accent} isLast />
      </IOSList>

      <IOSList header="Targets">
        <IOSListRow title="Glucose Range" detail="70–180 mg/dL" icon={T.green} />
        <IOSListRow title="Daily MET Goal" detail="500 MET·min" icon={T.ringMet} />
        <IOSListRow title="Carb Ratio" detail="1 : 10" icon={T.amber} isLast />
      </IOSList>

      <IOSList header="Data">
        <IOSListRow title="Export Health Report" icon={accent} />
        <IOSListRow title="Share with Clinician" icon={T.teal} />
        <IOSListRow title="Notifications" icon={T.violet} isLast />
      </IOSList>
    </div>
  );
}

// ── GLUCOSE DETAIL (overlay) ──────────────────────────────────
function GlucoseDetail({ accent, mmol, onBack }) {
  const T = window.TOKENS;
  const st = glucoseStatus(DATA.current);
  return (
    <div style={{ ...SCROLL, gap: 14 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 0 2px', cursor: 'pointer' }} onClick={onBack}>
        <svg width="12" height="20" viewBox="0 0 12 20" fill="none"><path d="M10 2L2 10l8 8" stroke={accent} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"/></svg>
        <span style={{ fontSize: 17, color: accent, fontWeight: 500 }}>Summary</span>
      </div>
      <div style={{ padding: '0 0 2px' }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: T.ink2, textTransform: 'uppercase', letterSpacing: 0.2 }}>Friday, Jun 19</div>
        <div style={{ fontSize: 32, fontWeight: 700, color: T.ink, letterSpacing: 0.36, lineHeight: 1.1 }}>Glucose</div>
      </div>

      <Card>
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 8 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
            <span style={{ fontSize: 52, fontWeight: 700, color: T.ink, letterSpacing: -1.5, lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>{fmtGlucose(DATA.current, mmol)}</span>
            <span style={{ fontSize: 15, fontWeight: 600, color: T.ink2 }}>{mmol ? 'mmol/L' : 'mg/dL'}</span>
          </div>
          <Chip color={st.color}><span style={{ width: 6, height: 6, borderRadius: 3, background: st.color, display: 'inline-block' }} />{st.label} · falling</Chip>
        </div>
        <GlucoseChart accent={accent} mmol={mmol} height={184} />
      </Card>

      <Card title="Today">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '18px 14px' }}>
          <StatBlock label="Average" value={fmtGlucose(DATA.avg, mmol)} unit={mmol ? 'mmol/L' : 'mg/dL'} />
          <StatBlock label="Time in Range" value={DATA.tir.inRange} unit="%" color={T.green} />
          <StatBlock label="Lowest" value={fmtGlucose(68, mmol)} color={T.red} />
          <StatBlock label="Highest" value={fmtGlucose(191, mmol)} color={T.amber} />
          <StatBlock label="Std. Dev" value={mmol ? '1.8' : '32'} />
          <StatBlock label="GMI" value="6.4" unit="%" />
        </div>
        <div style={{ height: 1, background: T.hair, margin: '16px 0 14px' }} />
        <div style={{ marginBottom: 8, fontSize: 12.5, fontWeight: 600, color: T.ink2, textTransform: 'uppercase', letterSpacing: 0.2 }}>Range Distribution</div>
        <TIRBar height={16} />
        <div style={{ display: 'flex', gap: 14, marginTop: 9 }}>
          {[['Low', DATA.tir.low, T.red], ['In Range', DATA.tir.inRange, T.green], ['High', DATA.tir.high, T.amber]].map(([l, v, c]) => (
            <span key={l} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11.5, color: T.ink2, fontWeight: 500 }}>
              <span style={{ width: 7, height: 7, borderRadius: 4, background: c }} />{l} {v}%
            </span>
          ))}
        </div>
      </Card>

      <Card icon="bolt" iconColor={accent} title="Events">
        {[
          { t: '7:30 AM', d: 'Breakfast · 62g carbs', c: T.amber },
          { t: '8:12 AM', d: 'Walk · −9 mg/dL', c: T.green },
          { t: '12:15 PM', d: 'Lunch · 48g carbs', c: T.amber },
          { t: '4:08 PM', d: 'Run · −38 mg/dL', c: T.green },
          { t: '5:55 PM', d: 'Snack · 22g (low treatment)', c: T.red },
        ].map((e, i, a) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '9px 0', borderBottom: i === a.length - 1 ? 'none' : `0.5px solid ${T.sep}` }}>
            <span style={{ width: 8, height: 8, borderRadius: 4, background: e.c, flexShrink: 0 }} />
            <span style={{ fontSize: 13, color: T.ink2, width: 64, fontVariantNumeric: 'tabular-nums' }}>{e.t}</span>
            <span style={{ fontSize: 14, color: T.ink, fontWeight: 500 }}>{e.d}</span>
          </div>
        ))}
      </Card>
    </div>
  );
}

Object.assign(window, { SummaryScreen, ActivityScreen, TrendsScreen, ProfileScreen, GlucoseDetail });
