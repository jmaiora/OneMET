// data.jsx — OneMET design tokens + mock health data
// Exports to window: TOKENS, glucoseStatus, DATA, fmtGlucose

const TOKENS = {
  bg:    '#EFEFF4',
  card:  '#FFFFFF',
  ink:   '#1C1C1E',
  ink2:  'rgba(60,60,67,0.60)',
  ink3:  'rgba(60,60,67,0.32)',
  sep:   'rgba(60,60,67,0.13)',
  hair:  'rgba(60,60,67,0.07)',
  // semantic
  green: '#30B85C',   // in-range
  amber: '#F5A02A',   // high
  red:   '#FF3B30',   // low / heart
  // activity ring hues (shared chroma, varied hue)
  ringMove: '#FF5A4D', // calories
  ringExer: '#5BD15B', // exercise minutes
  ringMet:  '#2A8FE0', // MET
  teal:  '#1FB8C9',
  violet:'#8E72E8',
};

const TARGET_LOW = 70;
const TARGET_HIGH = 180;

function glucoseStatus(mgdl) {
  if (mgdl < TARGET_LOW) return { label: 'Low', color: TOKENS.red };
  if (mgdl > TARGET_HIGH) return { label: 'High', color: TOKENS.amber };
  return { label: 'In Range', color: TOKENS.green };
}

// Build a realistic Type-1 glucose curve across the day (mg/dL).
// 5-min cadence → 288 pts. Key beats: dawn rise, breakfast spike + correction,
// lunch, afternoon run causing a dip toward low, recovery, dinner spike, settle.
function buildGlucose() {
  const pts = [];
  const seg = (from, to, a, b, noise = 4) => {
    const n = to - from;
    for (let i = 0; i < n; i++) {
      const t = i / n;
      // smoothstep
      const s = t * t * (3 - 2 * t);
      const v = a + (b - a) * s + (Math.sin(i * 1.7) + Math.cos(i * 0.9)) * noise * 0.5;
      pts.push(Math.round(v));
    }
  };
  // index = minutes/5 ; 0 = 00:00
  seg(0, 36, 118, 104);     // 0–3h  overnight settle
  seg(36, 72, 104, 96);     // 3–6h  dawn dip
  seg(72, 84, 96, 132);     // 6–7h  dawn rise
  seg(84, 108, 132, 191);   // 7–9h  breakfast spike
  seg(108, 144, 191, 124);  // 9–12h correction
  seg(144, 168, 124, 168);  // 12–14h lunch
  seg(168, 192, 168, 138);  // 14–16h settle
  seg(192, 204, 138, 96);   // 16–17h run begins, drop
  seg(204, 216, 96, 68);    // 17–18h run low
  seg(216, 240, 68, 122);   // 18–20h carb recovery
  seg(240, 264, 122, 174);  // 20–22h dinner spike
  seg(264, 288, 174, 120);  // 22–24h settle
  return pts;
}

const GLUCOSE = buildGlucose();
const CURRENT_IDX = 210; // ~17:30, just after the run dip recovering
const CURRENT = GLUCOSE[CURRENT_IDX];

// time-in-range for today
function computeTIR(arr) {
  let low = 0, inr = 0, high = 0;
  arr.forEach(v => {
    if (v < TARGET_LOW) low++;
    else if (v > TARGET_HIGH) high++;
    else inr++;
  });
  const n = arr.length;
  return {
    low: Math.round((low / n) * 100),
    inRange: Math.round((inr / n) * 100),
    high: Math.round((high / n) * 100),
  };
}

const DATA = {
  TARGET_LOW, TARGET_HIGH,
  glucose: GLUCOSE,
  currentIdx: CURRENT_IDX,
  current: CURRENT,
  currentTrend: -2, // mg/dL per 5 min → falling slowly
  avg: Math.round(GLUCOSE.reduce((a, b) => a + b, 0) / GLUCOSE.length),
  tir: computeTIR(GLUCOSE),
  rings: {
    move:  { value: 540, goal: 620, unit: 'KCAL' },
    exer:  { value: 42,  goal: 45,  unit: 'MIN' },
    met:   { value: 486, goal: 500, unit: 'MET·MIN' },
  },
  steps: 8432,
  stepsGoal: 10000,
  // MET-min accumulated by 2h bucket
  metByHour: [0, 0, 0, 12, 64, 28, 18, 30, 196, 84, 38, 16],
  heart: {
    current: 64,
    resting: 58,
    range: [52, 158],
    // bpm over day sampled (range band low/high per bucket)
    series: [58,57,56,58,72,88,76,70,74,150,96,74],
  },
  workouts: [
    { name: 'Outdoor Run', time: '4:08 PM', dur: '32 min', dist: '5.2 km',
      kcal: 348, avgMet: 9.1, hr: 152, glucoseDelta: -38 },
    { name: 'Walk', time: '8:12 AM', dur: '18 min', dist: '1.4 km',
      kcal: 72, avgMet: 3.2, hr: 104, glucoseDelta: -9 },
  ],
  nutrition: {
    carbs: 168, carbsGoal: 200, insulinUnits: 24,
    meals: [
      { name: 'Breakfast', carbs: 62, time: '7:30 AM' },
      { name: 'Lunch',     carbs: 48, time: '12:15 PM' },
      { name: 'Snack',     carbs: 22, time: '5:55 PM' },
      { name: 'Dinner',    carbs: 36, time: '8:00 PM' },
    ],
  },
  // 14-day time-in-range trend (% in range)
  tirTrend: [71, 68, 74, 80, 77, 82, 79, 73, 85, 88, 81, 84, 90, 86],
  // glucose vs activity correlation scatter (metMin, tirPct)
  corr: [
    [120, 64], [180, 70], [240, 72], [300, 78], [360, 80],
    [420, 83], [486, 86], [540, 88], [200, 68], [330, 76],
  ],
};

function fmtGlucose(mgdl, mmol) {
  return mmol ? (mgdl / 18).toFixed(1) : String(Math.round(mgdl));
}

Object.assign(window, { TOKENS, glucoseStatus, DATA, fmtGlucose, TARGET_LOW, TARGET_HIGH });
